#import <Flutter/Flutter.h>

@interface InternetSpeedTestPlugin : NSObject<FlutterPlugin>
@end
