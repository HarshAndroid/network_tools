enum CallbacksEnum {
  START_DOWNLOAD_TESTING,
  START_UPLOAD_TESTING,
}

enum ListenerEnum {
  COMPLETE,
  ERROR,
  PROGRESS,
}

enum SpeedUnit {
  Kbps,
  Mbps,
}
