## 1.5.0

* Migrate to Flutter 2.2 and null-safety

## 1.1.2+1

* Fix upload timeout with iOS

## 1.1.2

* Fix iOS download & upload issue

## 1.1.1

* Fix iOS build issue

## 1.1.0

* Adding the ability to customize your speed test server

## 1.0.2

* Implement for iOS


## 1.0.1+1

* Fix readme


## 1.0.1

* Always return transfer rate with Mb/s instead of Kb/s


## 1.0.0

* Initial release supporting download and upload internet speed test, working for Android only.

